Greetings All
This SunCalc is supposed to be an improved version of a previous calculator I made.
The Warnings Suppressed in Storing.java are just warnings saying that fields can be local and a few methods are unused.
If there's any way to improve the code, feel free to tell me, because we all learn somehow.
